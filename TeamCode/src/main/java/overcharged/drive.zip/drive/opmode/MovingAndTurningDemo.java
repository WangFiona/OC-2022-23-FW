package overcharged.drive.opmode;

import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.trajectory.Trajectory;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import overcharged.drive.SampleMecanumDrive;

@Autonomous(name="fwdandback")
public class MovingAndTurningDemo extends LinearOpMode {
    @Override
    public void runOpMode(){
        SampleMecanumDrive drive = new SampleMecanumDrive(hardwareMap);

        waitForStart();

        Trajectory first = drive.trajectoryBuilder(new Pose2d()).forward(60).build();
        Trajectory second = drive.trajectoryBuilder(first.end()).back(60).build();

        while(opModeIsActive() && !isStopRequested()){
            drive.followTrajectory(first);
            sleep(1000);
            drive.followTrajectory(second);
            sleep(1000);
        }

    }
}
